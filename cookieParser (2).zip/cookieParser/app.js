var express=require('express')
var app=express();

app.get('/',function(req,res){
    res.cookie('name', 'Flavio', { expires: new Date(Date.now() + 900000), httpOnly: true })
    res.end('Hello......');
   
});

   

app.listen(4200,function(){
    console.log('server started');
})

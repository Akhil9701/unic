var Arith = require('./operations')


var acb = function (err, data) {
    if (err) {
        console.log(err);
    }
    else {
        console.log("The result is  : " + data)
    }
}


var a = 24; 
var b = 12;



Arith.Addition(a,b,acb);
Arith.Substraction(a,b,acb);
Arith.Multiplication(a,b,acb);
Arith.Division(a,b,acb);
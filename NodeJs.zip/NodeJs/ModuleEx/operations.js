
var ArithObj = {


    Division: function (num1, num2, cbf) {
        try {
            if (num2 == 0) {
                throw new Error('Divison is not possible with 0')
            }
            else if ((isNaN(num1) || isNaN(num2))) {
                throw new Error('Didvision not possible with chars..')
            }
            else {
                var res = num1 / num2;
                cbf(undefined, res);
            }
        }
        catch (err) {
            cbf(err);
        }
    },



    Addition: function (num1, num2, cbf) {
        try {
            if ((isNaN(num1) || isNaN(num2))) {
                throw new Error('Addition not possible with chars..')
            }
            else {
                var res = num1 + num2;
                cbf(undefined, res);
            }
        }
        catch (err) {
            cbf(err);
        }
    },


    Substraction: function (num1, num2, cbf) {
        try {
            if ((isNaN(num1) || isNaN(num2))) {
                throw new Error('Substraction not possible with chars..')
            }
            else {
                var res = num1 - num2;
                cbf(undefined, res);
            }
        }
        catch (err) {
            cbf(err);
        }
    },


    Multiplication: function (num1, num2, cbf) {
        try {
            if ((isNaN(num1) || isNaN(num2))) {
                throw new Error('Multiplication not possible with chars..')
            }
            else {
                var res = num1 * num2;
                cbf(undefined, res);
            }
        }
        catch (err) {
            cbf(err);
        }
    }

}

module.exports = ArithObj






function myCallBack (res){
    console.log(res)
}
function evenOrOdd(n,cbf){
    if(n%2==0)
    cbf("the number is even")
    else
    cbf("the number is odd")
}

var a=44;
var b=56;
evenOrOdd(a,myCallBack);
evenOrOdd(b,myCallBack);













var fs=require('fs')
var path=require('path')
var http=require('http')
var server=http.createServer();
server.on('request',(req,res)=>{
    var fileName=path.join(__dirname,'home.html')
    fs.writeFile(fileName,(err,data)=>{
        if(err)
        res.end('<h4> server side error </h4>')
        else
        res.end(data)
    })
})

server.listen(4200,(err)=>{
    if(err)
    {
        console.log("server not started.....error...")
    }
    else{
        console.log("server started... at http://localhost:4200");
    }
})
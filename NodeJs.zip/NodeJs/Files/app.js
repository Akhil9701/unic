var fs = require('fs');
var path = require('path')
var myData = "We are learning NodeJs"
var filePath = path.join(__dirname,"myFile1.txt");
fs.writeFile(filePath,myData,function(err){
if(err){
    console.log("Write Error Occured ...!" + err)
}
else
{
    console.log('Write File Successxxx......')
}
})


var fs  = require('fs');
var path = require('path');


var filePath = path.join(__dirname, 'myFile.txt');

fs.readFile(filePath,function(err,data){
    if(err){
        console.log("Read Error...!" + err)
    }
    else{
        console.log("Data from File : " + data )
    }
})
 // Example of FileWatcher

var fs  = require('fs');
var path = require('path');

var filePath = path.join(__dirname, 'myFile.txt');


fs.exists(filePath,function(flag){
    if(flag)
    {
        
        console.log('File is Under Watch.........')
        fs.watchFile(filePath,{interval:3000},function(cur,prev){
            console.log("File modified at  :  " + cur.mtime);
            console.log("Current File Size :  " + cur.size);
            console.log("-------------------------------")
            console.log('Prev File Size : '+ prev.size);
        })
    }
    else{
        console.log('File Not Exists ...')
    }
})

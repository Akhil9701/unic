var array1 = ['I am working at'];
var array2 = ['Unic Sol'];


console.log(__dirname);
console.log(__filename);
global.authName = "AKhil";
global.companyName = "TSE";
console.log(array1.concat(array2));

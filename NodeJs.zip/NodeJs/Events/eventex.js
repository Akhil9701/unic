var events=require('events')
var evmObj=new events.EventEmitter()
evmObj.on("Click",function(){
console.log("Today is :"+ new Date());
})
evmObj.on("Click",function(){
console.log("Hi gus whats going on.....")
})

evmObj.emit("Click");
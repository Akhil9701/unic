var events=require('events');
class myClass extends events{

}
var obj=new myClass();
obj.on("btnclick",()=>{console.log("Button clicked")});
obj.emit("btnclick");
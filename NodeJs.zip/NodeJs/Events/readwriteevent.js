var fs=require('fs');
var readMe = fs.readFileSync('readMe.txt','utf8');
fs.writeFileSync('WriteMe.txt',readMe);
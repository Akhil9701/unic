var http=require('http');
var server=http.createServer();
server.on("request",(req,res)=>{
    res.end("Welcome to Nodejs")
})
server.listen(4200,(err)=>{
    if(err)
    {
        console.log("server not started.....error....")
    }
      else{
          console.log("server started... at http://localhost:4200");
    }

})

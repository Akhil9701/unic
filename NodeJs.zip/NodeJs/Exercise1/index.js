var divide = function (num1, num2, callback) {
try 
{
    if (num2 === 0) {
        throw new Error("Division Error..");
    }
    else {
        var res = 5/0;
        callback(res);
    }
}
catch(err)
{
callback(undefined, err);
}
}

module.exports.divide= divide;

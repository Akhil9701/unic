var divide = require("./ModuleEx.js");

var callbackFunction = function(data, err)
{
    if(err)
        {
            console.log("Erorr occured......");
        }
        else
            {
            console.log(data);
            }
}
divide.divide(5,0,callbackFunction);
